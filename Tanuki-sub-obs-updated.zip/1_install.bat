@echo off
cd /d "%~dp0"

echo ============================================================
echo   Checking Python and installing required packages...
echo ============================================================

python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Python was not found.
    echo Install Python from https://www.python.org/downloads/
    echo During setup, enable: Add python.exe to PATH
    echo.
    pause
    exit /b 1
)

python -m pip install --upgrade pip
python -m pip install --upgrade -r requirements.txt
if errorlevel 1 (
    echo.
    echo [ERROR] Installation did not finish successfully.
    echo Check your Internet connection, then run this file again.
    echo If PyAudio fails, install the Microsoft C++ Build Tools or ask the pack creator for help.
    echo.
    pause
    exit /b 1
)

python -c "import pyaudio; import google.genai; from PySide6 import QtWidgets; print('All required components are ready.')"
if errorlevel 1 (
    echo.
    echo [ERROR] A required component could not be loaded. Run this installer again.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   Done! You can now double-click 2_start_subtitles.bat
echo ============================================================
pause
