@echo off
cd /d "%~dp0"

if not exist "icon1.ico" (
    echo.
    echo [!] icon1.ico not found in this folder.
    echo     Please put your icon file here and name it exactly: icon1.ico
    echo.
    pause
    exit /b 1
)

echo Creating shortcuts with your custom icon...

powershell -NoProfile -Command ^
    "$ws = New-Object -ComObject WScript.Shell;" ^
    "$target = (Join-Path (Get-Location) '2_start_subtitles.bat');" ^
    "$iconPath = (Join-Path (Get-Location) 'icon1.ico');" ^
    "foreach ($dest in @([System.IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), 'Tanuki Sub OBS.lnk'), (Join-Path (Get-Location) 'Tanuki Sub OBS.lnk'))) {" ^
    "  $s = $ws.CreateShortcut($dest);" ^
    "  $s.TargetPath = $target;" ^
    "  $s.WorkingDirectory = (Get-Location).Path;" ^
    "  $s.IconLocation = $iconPath;" ^
    "  $s.Description = 'Open Tanuki Sub OBS';" ^
    "  $s.Save();" ^
    "}"

echo.
echo Done! A "Live Subtitles" shortcut with your icon was created:
echo   - on your Desktop
echo   - in this folder
echo Double-click either one to start the subtitles program.
echo.
pause
