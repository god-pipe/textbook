"""Tanuki Sub OBS: cyberpunk desktop control panel (English UI)."""
import json
import os
import subprocess
import sys

import pyaudio
from PySide6.QtCore import Qt, QTimer, QUrl
from PySide6.QtGui import QDesktopServices, QPixmap
from PySide6.QtWidgets import (QApplication, QCheckBox, QComboBox, QFrame, QGridLayout,
    QHBoxLayout, QLabel, QLineEdit, QMainWindow, QMessageBox, QPushButton, QTextEdit,
    QVBoxLayout, QWidget)

ROOT = os.path.dirname(os.path.abspath(__file__))
CONFIG, ENGINE = os.path.join(ROOT, "config.json"), os.path.join(ROOT, "obs_live_subtitles.py")
ENGINE_LOG = os.path.join(ROOT, "tanuki_engine.log")
LANGS = (("zh", "TRADITIONAL CHINESE", "subtitle_zh.txt"), ("en", "ENGLISH", "subtitle_en.txt"), ("ja", "JAPANESE", "subtitle_ja.txt"))
BG, CARD, INPUT, CYAN, PINK, TEXT, MUTED, GREEN = "#080b18", "#11172b", "#18213b", "#29f5ff", "#ff3cac", "#edf8ff", "#9badc9", "#7dffb2"

STYLE = f"""
QMainWindow, QWidget {{ background:{BG}; color:{TEXT}; font-family: Consolas; }}
QFrame#card {{ background:{CARD}; border:1px solid #294260; }}
QLabel#title {{ font: bold 28px Arial; color:{CYAN}; }} QLabel#pink {{ font: bold 28px Arial; color:{PINK}; }}
QLabel#section {{ color:{CYAN}; font-weight:bold; }} QLabel#hint {{ color:{MUTED}; font-size:11px; }}
QLineEdit, QComboBox, QTextEdit {{ background:{INPUT}; border:1px solid #35516f; color:{TEXT}; padding:7px; }}
QLineEdit:focus, QComboBox:focus {{ border:1px solid {CYAN}; }}
QPushButton {{ background:#243452; color:{TEXT}; border:0; padding:9px 14px; font-weight:bold; }}
QPushButton:hover {{ background:{CYAN}; color:{BG}; }} QPushButton#start {{ background:{PINK}; color:{BG}; padding:11px 18px; }}
QCheckBox {{ color:{TEXT}; padding:4px; }} QCheckBox::indicator {{ width:15px; height:15px; }}
"""

class App(QMainWindow):
    def __init__(self):
        super().__init__(); self.setWindowTitle("TANUKI SUB OBS // LIVE CONTROL"); self.resize(1040, 760); self.setMinimumSize(920, 680)
        self.proc, self.log_handle, self.devices = None, None, []
        self.form_dirty = False
        self.last_status_mode = None
        self.closing = False
        try:
            with open(CONFIG, encoding="utf-8") as f: self.cfg = json.load(f)
        except (OSError, json.JSONDecodeError): self.cfg = {}
        self.build(); self.refresh_devices(); self.watch_setting_changes()
        self.timer = QTimer(self); self.timer.timeout.connect(self.poll); self.timer.start(350)

    def section(self, title):
        card = QFrame(); card.setObjectName("card"); layout = QVBoxLayout(card); layout.setContentsMargins(17, 13, 17, 12); layout.setSpacing(7)
        label = QLabel("// " + title); label.setObjectName("section"); layout.addWidget(label); return card, layout
    def hint(self, text):
        label=QLabel(text); label.setObjectName("hint"); label.setWordWrap(True); return label

    def set_status(self, text, color, surface, mode=None, sound=False):
        """Keep the engine state unmistakable at a glance."""
        self.status.setText(text)
        self.status.setStyleSheet(
            f"background:{surface}; color:{color}; border:1px solid {color}; "
            "border-radius:5px; padding:8px 11px; font-weight:bold;"
        )
        if mode in ("online", "offline", "connecting"):
            icon_name = "tanuki_online.png" if mode == "online" else "tanuki_offline.png"
            pixmap = QPixmap(os.path.join(ROOT, "assets", icon_name))
            if not pixmap.isNull():
                self.status_icon.setPixmap(pixmap.scaled(42, 42, Qt.KeepAspectRatio, Qt.SmoothTransformation))
            changed = mode != self.last_status_mode
            self.last_status_mode = mode
            if sound and changed and getattr(self, "status_sounds", None) and self.status_sounds.isChecked():
                QApplication.beep()

    def watch_setting_changes(self):
        """Warn clearly when saved settings differ from the running engine."""
        controls = [self.api, self.mic, self.combined, self.idle, self.hold, self.gain, self.noise_gate, *self.langvars.values(), *self.max_chars.values()]
        for control in controls:
            if isinstance(control, QLineEdit): control.textChanged.connect(self.mark_dirty)
            elif isinstance(control, QComboBox): control.currentIndexChanged.connect(self.mark_dirty)
            else: control.stateChanged.connect(self.mark_dirty)

    def mark_dirty(self, *_):
        self.form_dirty = True
        if self.proc and self.proc.poll() is None:
            self.set_status("● SETTINGS CHANGED — CLICK SAVE TO APPLY", PINK, "#351426")

    def build(self):
        root=QWidget(); self.setCentralWidget(root); outer=QVBoxLayout(root); outer.setContentsMargins(28,22,28,23); outer.setSpacing(10)
        header=QHBoxLayout(); mascot=QLabel(); pix=QPixmap(os.path.join(ROOT,"assets","tanuki_mascot.png"))
        if not pix.isNull(): mascot.setPixmap(pix.scaled(60,60,Qt.KeepAspectRatio,Qt.SmoothTransformation)); header.addWidget(mascot)
        title=QLabel("TANUKI"); title.setObjectName("title"); header.addWidget(title); subtitle=QLabel(" SUB OBS"); subtitle.setObjectName("pink"); header.addWidget(subtitle); header.addStretch()
        # Compact Japan flag plus sakura/sparkle accents; deliberately confined to the header.
        accent=QLabel("🇯🇵   ✿  ✦  ✿"); accent.setStyleSheet(f"color:{PINK}; font-size:18px;"); header.addWidget(accent)
        self.status_icon=QLabel(); self.status_icon.setFixedSize(46,46); self.status_icon.setAlignment(Qt.AlignCenter); header.addWidget(self.status_icon)
        self.status=QLabel(); self.status.setMinimumWidth(270); self.status.setMinimumHeight(38); self.status.setAlignment(Qt.AlignCenter)
        self.set_status("● OFFLINE — SUBTITLES STOPPED", PINK, "#351426", "offline"); header.addWidget(self.status); outer.addLayout(header)
        outer.addWidget(self.hint("LIVE TRANSLATION CONTROL PANEL  /  OBS TEXT FILE OUTPUT"))
        grid=QGridLayout(); grid.setHorizontalSpacing(14); grid.setVerticalSpacing(14); grid.setRowStretch(1,1); outer.addLayout(grid,1)
        conn,cl=self.section("GEMINI API & USAGE"); self.api=QLineEdit(self.cfg.get("gemini_api_key","")); self.api.setEchoMode(QLineEdit.Password); cl.addWidget(self.hint("GEMINI API KEY")); cl.addWidget(self.api)
        links=QHBoxLayout(); key_button=QPushButton("GET API KEY ↗"); key_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://aistudio.google.com/apikey"))); links.addWidget(key_button)
        quota_button=QPushButton("VIEW QUOTA ↗"); quota_button.clicked.connect(lambda: QDesktopServices.openUrl(QUrl("https://aistudio.google.com/usage"))); links.addWidget(quota_button); links.addStretch(); cl.addLayout(links)
        cl.addWidget(self.hint("FREE TIER: rate-limited, not a daily minute bank. If your TPM stays below your project limit, it can run all day."))
        cl.addWidget(self.hint("GUIDE: 1 language is about 4.5K TPM; 3 languages about 13.7K of a typical 20K TPM limit. Limits vary by project."))
        cl.addWidget(self.hint("PAID ESTIMATE: about US$2.21 per hour for each selected translation language. Check AI Studio for your actual tier and current usage."))
        cl.addWidget(self.hint("LIVE REMAINING QUOTA: shown in AI Studio only. This app does not upload your API key to query usage.")); grid.addWidget(conn,0,0)
        audio,al=self.section("AUDIO INPUT"); self.mic=QComboBox(); al.addWidget(self.mic); refresh=QPushButton("REFRESH DEVICES"); refresh.clicked.connect(self.refresh_devices); al.addWidget(refresh,alignment=Qt.AlignLeft)
        tuning=QHBoxLayout(); self.gain=QLineEdit(str(self.cfg.get("audio_gain",1.0))); self.gain.setMaximumWidth(56)
        tuning.addWidget(self.hint("MIC GAIN (x)")); tuning.addWidget(self.gain)
        self.noise_gate=QLineEdit(str(self.cfg.get("noise_gate_threshold",0))); self.noise_gate.setMaximumWidth(56)
        tuning.addWidget(self.hint("NOISE GATE (RMS)")); tuning.addWidget(self.noise_gate); tuning.addStretch(); al.addLayout(tuning)
        al.addWidget(self.hint("GAIN: multiplies mic volume before it reaches Gemini. 1.0 = unchanged (default). Raise to 1.5-2.5 if quiet speech gets missed/garbled; lower to 0.5-0.8 if the input already sounds hot. Range 0.1-5.0, auto-clipped so it can't distort."))
        al.addWidget(self.hint("NOISE GATE: mutes audio quieter than this loudness (RMS) instead of sending it to Gemini, so room hiss/background noise doesn't turn into stray subtitles. 0 = off (default). Try 150-400 in a noisy room; leave at 0 if your room is quiet or subtitles ever cut out during soft speech."))
        grid.addWidget(audio,0,1)
        out,ol=self.section("TRANSLATION OUTPUTS"); ol.addWidget(self.hint("Selected languages are the only Gemini sessions billed.")); self.langvars={}; selected=self.cfg.get("selected_languages",["zh"])
        for key,name,file in LANGS:
            box=QCheckBox(f"{name:<22}  →  {file}"); box.setChecked(key in selected); self.langvars[key]=box; ol.addWidget(box)
        self.combined=QCheckBox("Create subtitle_all.txt (combined)"); self.combined.setChecked(self.cfg.get("write_combined_file",False)); ol.addWidget(self.combined); ol.addStretch(); ol.addWidget(self.hint("OBS: Text (FreeType 2) → Read from file → choose its subtitle_*.txt.")); grid.addWidget(out,1,0)
        preview,pl=self.section("LIVE TEXT PREVIEW"); self.preview=QTextEdit(); self.preview.setReadOnly(True); self.preview.setStyleSheet(f"color:{GREEN}; font-size:15px; background:#060914;"); pl.addWidget(self.preview,1); grid.addWidget(preview,1,1)
        controls=QHBoxLayout(); self.idle=QLineEdit(str(self.cfg.get("idle_clear_sec",8.0))); self.hold=QLineEdit(str(self.cfg.get("hold_after_turn_sec",2.5)))
        for name,field in (("CLEAR AFTER IDLE (SEC)",self.idle),("HOLD AFTER SPEECH (SEC)",self.hold)):
            controls.addWidget(self.hint(name)); field.setMaximumWidth(62); controls.addWidget(field)
        controls.addStretch(); self.status_sounds=QCheckBox("STATUS SOUNDS"); self.status_sounds.setChecked(self.cfg.get("status_sounds", True)); controls.addWidget(self.status_sounds); save=QPushButton("SAVE SETTINGS"); save.clicked.connect(self.save); controls.addWidget(save); self.run=QPushButton("▶ START LIVE SUBTITLES"); self.run.setObjectName("start"); self.run.clicked.connect(self.start); controls.addWidget(self.run); outer.addLayout(controls)
        segments=QHBoxLayout(); segments.addWidget(self.hint("SUBTITLE SEGMENT LENGTH (CHARACTERS)")); self.max_chars={}; saved_caps=self.cfg.get("max_subtitle_chars", {"zh":18,"en":42,"ja":18})
        for key, label, default in (("zh","ZH",18),("en","EN",42),("ja","JA",18)):
            segments.addWidget(self.hint(label)); field=QLineEdit(str(saved_caps.get(key,default))); field.setMaximumWidth(54); self.max_chars[key]=field; segments.addWidget(field)
        segments.addStretch(); segments.addWidget(self.hint("A new subtitle cue starts after this limit, or at sentence-ending punctuation.")); outer.addLayout(segments)

    def refresh_devices(self):
        pa=pyaudio.PyAudio(); self.devices=[]
        try:
            for i in range(pa.get_device_count()):
                info=pa.get_device_info_by_index(i)
                if info.get("maxInputChannels",0)>0: self.devices.append((i,info["name"]))
        finally: pa.terminate()
        self.mic.clear()
        for i,name in self.devices: self.mic.addItem(f"#{i}  {name}",i)
        saved=self.cfg.get("mic_device_index"); pos=next((n for n,(i,_) in enumerate(self.devices) if i==saved),0); self.mic.setCurrentIndex(pos)

    def save(self):
        selected=[key for key,_,_ in LANGS if self.langvars[key].isChecked()]
        try:
            if not self.api.text().strip(): raise ValueError("Enter your Gemini API key.")
            if not selected: raise ValueError("Select at least one translation output.")
            if self.mic.currentData() is None: raise ValueError("Select an audio input device.")
            mic=self.mic.currentData(); name=next(n for i,n in self.devices if i==mic)
            max_chars={key:int(field.text()) for key,field in self.max_chars.items()}
            if any(value < 1 or value > 300 for value in max_chars.values()): raise ValueError("Segment lengths must be between 1 and 300 characters.")
            try: audio_gain=float(self.gain.text())
            except ValueError: raise ValueError("Mic gain must be a number (e.g. 1.0).")
            if audio_gain < 0.1 or audio_gain > 5.0: raise ValueError("Mic gain must be between 0.1 and 5.0.")
            try: noise_gate=int(float(self.noise_gate.text()))
            except ValueError: raise ValueError("Noise gate must be a number (e.g. 0).")
            if noise_gate < 0 or noise_gate > 5000: raise ValueError("Noise gate must be between 0 and 5000.")
            self.cfg={"gemini_api_key":self.api.text().strip(),"mic_device_index":mic,"mic_device_name":name,"selected_languages":selected,"write_combined_file":self.combined.isChecked(),"idle_clear_sec":float(self.idle.text()),"hold_after_turn_sec":float(self.hold.text()),"max_subtitle_chars":max_chars,"status_sounds":self.status_sounds.isChecked(),"audio_gain":audio_gain,"noise_gate_threshold":noise_gate}
        except ValueError as error: QMessageBox.critical(self,"Tanuki Sub OBS",str(error)); return False
        with open(CONFIG,"w",encoding="utf-8") as f: json.dump(self.cfg,f,indent=2)
        was_running = self.proc and self.proc.poll() is None
        changed_while_running = was_running and self.form_dirty
        self.form_dirty = False
        if changed_while_running:
            answer = QMessageBox.question(self, "Apply settings now?",
                "Your settings were saved, but the live subtitle engine needs a restart to use them.\n\nRestart it now?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if answer == QMessageBox.Yes:
                self.stop(silent=True)
                QTimer.singleShot(400, self.start)
                return True
            self.set_status("● SAVED — STOP & START TO APPLY", PINK, "#351426")
            return True
        self.set_status("● SETTINGS SAVED", CYAN, "#102b3c"); return True

    def start(self):
        if self.proc and self.proc.poll() is None: return
        if not self.save(): return
        self.log_handle=open(ENGINE_LOG,"w",encoding="utf-8")
        self.proc=subprocess.Popen([sys.executable,"-u",ENGINE],cwd=ROOT,stdout=self.log_handle,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)); self.set_status("● CONNECTING — ENGINE STARTING", CYAN, "#102b3c", "connecting"); self.run.setText("■ STOP LIVE SUBTITLES"); self.run.clicked.disconnect(); self.run.clicked.connect(self.stop)
    def clear_subtitle_files(self):
        """Never leave a stale OBS caption visible after Stop or an engine failure."""
        for _, _, filename in LANGS:
            try:
                with open(os.path.join(ROOT, filename), "w", encoding="utf-8"):
                    pass
            except OSError: pass
        try:
            with open(os.path.join(ROOT, "subtitle_all.txt"), "w", encoding="utf-8"):
                pass
        except OSError: pass
        self.preview.clear()
    def stop(self, failed=False, silent=False):
        if self.proc and self.proc.poll() is None: self.proc.terminate()
        if self.log_handle: self.log_handle.close(); self.log_handle=None
        self.clear_subtitle_files()
        self.proc=None
        if not failed:
            self.set_status("● OFFLINE — SUBTITLES STOPPED", PINK, "#351426", "offline", sound=not silent and not self.closing)
        self.run.setText("▶ START LIVE SUBTITLES"); self.run.clicked.disconnect(); self.run.clicked.connect(self.start)
    def poll(self):
        if self.proc and self.proc.poll() is not None:
            try:
                with open(ENGINE_LOG, encoding="utf-8", errors="replace") as f: detail=f.read().strip().splitlines()[-1]
                self.set_status(f"● ENGINE ERROR: {detail[:55]}", PINK, "#351426", "offline")
            except OSError: pass
            self.stop(failed=True)
        elif self.proc:
            # Translate-session failures are retried by the engine, so surface them
            # here even though the child process itself stays alive.
            try:
                with open(ENGINE_LOG, encoding="utf-8", errors="replace") as f:
                    last_line = next((line for line in reversed(f.read().splitlines()) if line.strip()), "")
                if "connection dropped" in last_line:
                    self.set_status(f"● CONNECTION WARNING: {last_line[:50]}", PINK, "#351426")
                elif "connected" in last_line:
                    self.set_status(f"● ONLINE — {last_line[:47]}", GREEN, "#123827", "online", sound=True)
            except OSError: pass
        lines=[]
        for key,name,file in LANGS:
            if self.langvars[key].isChecked():
                try:
                    with open(os.path.join(ROOT,file),encoding="utf-8") as f: text=f.read().strip()
                    if text: lines.append(f"[{name}]\n{text}")
                except OSError: pass
        self.preview.setPlainText("\n\n".join(lines) or "Waiting for subtitle output...")
    def closeEvent(self,event): self.closing=True; self.stop(silent=True); event.accept()

if __name__ == "__main__":
    app=QApplication(sys.argv); app.setStyleSheet(STYLE); window=App(); window.show(); sys.exit(app.exec())
