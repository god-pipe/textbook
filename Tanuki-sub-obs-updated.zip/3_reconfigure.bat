@echo off
chcp 65001 >nul
cd /d "%~dp0"

python tanuki_sub_obs.py
