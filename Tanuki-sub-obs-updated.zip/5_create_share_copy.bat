@echo off
chcp 65001 >nul
cd /d "%~dp0"

set "SHARE_DIR=%~dp0Tanuki-Sub-OBS-Share"

if exist "%SHARE_DIR%" (
    echo.
    echo [ERROR] A previous Tanuki-Sub-OBS-Share folder already exists here.
    echo Rename or remove that copy first, then run this file again.
    echo.
    pause
    exit /b 1
)

echo Creating a safe share copy without your API key or logs...
powershell -NoProfile -Command ^
  "$source = (Get-Location).Path;" ^
  "$dest = Join-Path $source 'Tanuki-Sub-OBS-Share';" ^
  "New-Item -ItemType Directory -Path $dest | Out-Null;" ^
  "Get-ChildItem -LiteralPath $source -Force | Where-Object { $_.Name -notin @('config.json','tanuki_engine.log','Tanuki-Sub-OBS-Share','__pycache__') } | Copy-Item -Destination $dest -Recurse -Force"

if errorlevel 1 (
    echo.
    echo [ERROR] The share copy could not be created.
    pause
    exit /b 1
)

echo.
echo Done. Send the Tanuki-Sub-OBS-Share folder to your friend.
echo Their first step is to run 1_install.bat, then 2_start_subtitles.bat.
echo Your API key was NOT copied.
echo.
pause
