@echo off
chcp 65001 >nul
cd /d "%~dp0"

python -c "from PySide6 import QtWidgets" >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERROR] Tanuki Sub OBS has not been installed yet.
    echo Please double-click 1_install.bat first.
    echo.
    pause
    exit /b 1
)

python tanuki_sub_obs.py

echo.
echo (Program ended. Press any key to close this window.)
pause >nul
