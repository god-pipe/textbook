# Tanuki Sub OBS — Setup Guide

Tanuki Sub OBS listens to a microphone (or virtual audio device), detects the
spoken language automatically, and writes selected translated subtitle files for OBS.

## One-time setup

1. **Install Python** (skip if you already have it)
   Download from https://www.python.org/downloads/
   During install, make sure to check **"Add python.exe to PATH"** —
   this step is easy to miss and things won't work without it.

2. **Install the required packages**
   Double-click `1_install.bat`. Only needs to be done once.

3. **First launch**
   Double-click `2_start_subtitles.bat`.
   - Paste your Gemini API key, choose an audio input, and tick only the
     output languages you need. Each selected language uses one Gemini session.
   - Set caption timing and click **Start Live Subtitles**. The panel previews
     the same `.txt` output OBS reads.

## Everyday use

Double-click `2_start_subtitles.bat`, then click **Start Live Subtitles**.
Click **Stop Live Subtitles** or close the panel to stop.

Open the panel again (or double-click `3_reconfigure.bat`) to change your
microphone, API key, languages, or timing.

### Audio tuning (optional)

If Gemini keeps missing quiet speech, garbling words, or turning room
noise into stray subtitles, the panel's **AUDIO INPUT** card has two
extra dials, both applied to the mic signal right before it's sent to
Gemini:

- **Mic gain (x)** — multiplies your mic's volume. `1.0` = unchanged.
  Try `1.5`–`2.5` if speech is too quiet; try `0.5`–`0.8` if it's
  already loud. The signal is clipped, not wrapped, so turning this up
  too far just sounds "flat", it never distorts into garbage.
- **Noise gate (RMS)** — mutes anything quieter than this loudness
  instead of sending it to Gemini. `0` = off. Try `150`–`400` in a
  noisy room. If subtitles ever cut out during soft speech, lower it
  or set it back to `0`.

## Sharing safely

Never send your own `config.json`: it contains your Gemini API key. Double-click
`5_create_share_copy.bat` to create a `Tanuki-Sub-OBS-Share` folder without your
key, logs, or temporary files. Your friend runs `1_install.bat` once, then
`2_start_subtitles.bat` and enters their own key.

## Setting up OBS

1. In OBS, add a **Text (FreeType 2)** source for each selected subtitle
   language you want to show (FreeType 2 refreshes faster than GDI+
   when the underlying file changes).
2. In its Properties, check **"Read from file"** and point it at one
   of these files (created in the same folder as the script, updated
   live while the program runs):
   - `subtitle_zh.txt` — Chinese
   - `subtitle_en.txt` — English
   - `subtitle_ja.txt` — Japanese
   - `subtitle_all.txt` — selected languages in one file (enable it in the panel)
3. Pick a font that supports CJK characters (e.g. Noto Sans CJK,
   Microsoft JhengHei) or Chinese/Japanese text will show as boxes.
4. Arrange/position the text sources however you like on your scene.

## Notes

- Subtitles behave like movie/TV captions: each line clears itself
  after a pause, and long sentences break into separate chunks
  instead of piling into one giant run-on line.
- The program automatically reconnects if the connection drops
  (Google's Live sessions are time-limited to roughly 10-15 minutes
  each) — you don't need to restart it during a long stream.
- `config.json` (created after first setup) contains your personal
  API key. Don't share it with anyone — if you're passing this whole
  folder to someone else, delete `config.json` first and let them run
  their own setup.
