"""
obs_live_subtitles.py
======================
Real-time translated subtitles for OBS, powered by Google's
Gemini 3.5 Live Translate model.

It listens to your microphone (or any audio input device, including
virtual audio cables), automatically detects the spoken language, and
produces three live subtitle files at the same time:
Chinese / English / Japanese. Point OBS text sources at those files
to show live translated captions on stream.

How it works
------------
Gemini 3.5 Live Translate is a speech-to-speech translation model.
Each Live session only supports ONE target language at a time, so
this script opens three parallel WebSocket sessions (zh-Hant / en /
ja) and feeds the same microphone audio into all three:
  - The spoken language is auto-detected (you never set a source
    language manually).
  - Every session is configured with echo_target_language=True:
      * If you happen to speak in that session's target language,
        the text is echoed back as-is.
      * Otherwise, it's translated into that session's target
        language.
  - Each session's transcribed text is written to its own file:
      subtitle_zh.txt / subtitle_en.txt / subtitle_ja.txt
    plus a combined file with all three lines: subtitle_all.txt

Subtitles that clear themselves (movie/TV style)
--------------------------------------------------
Instead of letting text pile up into one giant run-on line, each
subtitle "cue" is capped at a max character count (shorter for
Chinese/Japanese, longer for English) or ends early at sentence-
ending punctuation. Once a cue is "finalized", the next bit of
speech starts a brand new cue instead of appending to the old one.
On top of that:
  - If there's no new text for a while, the subtitle auto-clears
    (the speaker paused / finished talking).
  - If the model detects the speaker was interrupted mid-sentence,
    the stale text is cleared immediately.

Audio input tuning
------------------
Two optional dials, set from the desktop panel, sit between the mic and
Gemini so a too-quiet, too-loud, or noisy input doesn't hurt subtitle
quality: a manual gain multiplier (boost/reduce volume, clipped so it
can't distort) and a noise gate (mutes background hiss below a loudness
threshold instead of letting Gemini try to transcribe it).

Automatic reconnect
--------------------
Gemini Live sessions are time-limited by Google (roughly 10-15
minutes per connection for audio-only sessions). For a stream that
runs for hours, that means the connection WILL eventually drop.
This script catches that automatically and reconnects in the
background — subtitles keep working, with only a brief gap while
it reconnects. You don't need to restart the program.

First-run setup wizard (no code editing needed)
--------------------------------------------------
The first time you run this, it will:
  1. List all detected audio input devices and let you pick one by
     number (works for real microphones AND virtual audio devices
     like VB-Cable, used to capture desktop/game/app audio).
  2. Ask for your Gemini API key once.
Both are saved into config.json next to this script. Every run
after that reads config.json automatically — no more prompts.

To change the microphone or API key later, run:
    python obs_live_subtitles.py --setup
(or just delete config.json — it will ask again on next run)

Note: config.json contains your personal API key. If you share this
folder with someone else, do NOT include your config.json — let
them run the setup wizard once and create their own.

Requirements
------------
pip install google-genai pyaudio

On Windows, if pyaudio fails to install:
    pip install pipwin
    pipwin install pyaudio

Gemini 3.5 Live Translate is currently a preview model — make sure
your Google AI Studio account has access to it:
https://ai.google.dev/gemini-api/docs/live-api/live-translate
Get an API key at: https://aistudio.google.com/apikey

OBS setup
---------
1. Add a "Text (FreeType 2)" source in OBS for each language you
   want to display (FreeType 2 updates faster than GDI+ when the
   underlying file changes).
2. In its properties, check "Read from file" and point it at:
     subtitle_zh.txt / subtitle_en.txt / subtitle_ja.txt
   (these files are created and continuously updated in the same
   folder as this script while it's running)
3. To show all three languages in a single text box instead, point
   one source at subtitle_all.txt (it always has 3 lines: zh/en/ja).
4. Use a font that supports CJK characters (e.g. Noto Sans CJK,
   Microsoft JhengHei) or Chinese/Japanese text will show as boxes.

Usage
-----
python obs_live_subtitles.py
First run asks for a microphone and API key. After that, it starts
capturing audio and generating subtitles immediately. Ctrl+C to stop.
"""

import array
import asyncio
import audioop
import json
import os
import sys

import pyaudio
from google import genai
from google.genai import types

# ---------------------------------------------------------------------------
# Basic configuration
# ---------------------------------------------------------------------------

MODEL = "gemini-3.5-live-translate-preview"

SAMPLE_RATE = 16000            # Gemini Live requires 16-bit PCM / 16kHz / mono
CHUNK_MS = 100                  # Send one audio chunk every 100ms (Google's guidance)
FRAMES_PER_CHUNK = int(SAMPLE_RATE * CHUNK_MS / 1000)
BYTES_PER_CHUNK = FRAMES_PER_CHUNK * 2   # 16-bit = 2 bytes per frame

# Target languages (BCP-47 codes). See the docs for the full supported list.
LANG_TARGETS = {
    "zh": "zh-Hant",   # Traditional Chinese (use "zh-Hans" for Simplified)
    "en": "en",
    "ja": "ja",
}

# --- Subtitle clearing timing (tune to taste) -------------------------------
IDLE_CLEAR_SEC = 8.0         # No new text for this long -> assume they're done, clear it
HOLD_AFTER_TURN_SEC = 2.5    # After a "turn complete" signal, keep it on screen a bit longer

# --- Per-cue length cap (movie/TV-style subtitles, not one giant run-on) ---
# Chinese/Japanese characters carry more meaning per character, so a shorter
# cap looks right; English words are longer, so it gets a bigger cap.
# Once a cue hits this length OR ends in sentence-ending punctuation, it's
# "finalized" — the next bit of speech starts a brand new cue instead of
# appending to this one.
MAX_SUBTITLE_CHARS = {"zh": 18, "en": 42, "ja": 18}
SENTENCE_END_CHARS = set("。！？!?.")

# --- Reconnect behavior ------------------------------------------------------
RECONNECT_DELAY_SEC = 2.0    # Wait this long before retrying after a dropped connection

# --- Audio input tuning (tune to taste) -------------------------------------
# Applied to the mic audio right before it's sent to Gemini, so a too-quiet
# or too-loud/noisy input doesn't hurt transcription/translation quality.
AUDIO_GAIN = 1.0             # Linear volume multiplier (1.0 = unchanged, >1 louder, <1 quieter). Clipped, never distorts.
NOISE_GATE_THRESHOLD = 0     # RMS loudness (0-5000ish) below which a chunk is muted to silence. 0 = disabled.

OUTPUT_DIR = os.path.dirname(os.path.abspath(__file__))
OUTPUT_FILES = {}
COMBINED_FILE = os.path.join(OUTPUT_DIR, "subtitle_all.txt")
CONFIG_PATH = os.path.join(OUTPUT_DIR, "config.json")

CONFIG = {}      # populated by run_setup_wizard() in __main__
client = None    # created in __main__ once we have an API key


# ---------------------------------------------------------------------------
# First-run setup wizard: pick a microphone + enter the API key once
# ---------------------------------------------------------------------------

def list_input_devices(pa):
    """Return every audio input device as [(index, name, channels, rate), ...]."""
    devices = []
    for i in range(pa.get_device_count()):
        info = pa.get_device_info_by_index(i)
        if info.get("maxInputChannels", 0) > 0:
            devices.append(
                (i, info["name"], int(info["maxInputChannels"]), int(info["defaultSampleRate"]))
            )
    return devices


def choose_microphone(pa):
    """
    List detected input devices and let the user type a device number.

    Important: you type the device's raw index (the same number shown on
    screen here), not its position in the list. That way, even if the
    listing is momentarily missing a device (virtual audio devices can be
    flaky about this), you can still type a known device number directly
    and the program will try to use it.
    """
    devices = list_input_devices(pa)
    if not devices:
        print("No audio input devices found. Please connect/enable a device and try again.")
        sys.exit(1)

    print("\n" + "=" * 60)
    print("Detected audio input devices:")
    print("=" * 60)
    for idx, name, ch, rate in devices:
        print(f"  #{idx:>3}  {name}  (channels={ch}, rate={rate})")
    print("=" * 60)
    print("Tip: if the device you want isn't listed above, you can still")
    print("type its device number directly and the program will try it.")
    print("=" * 60)

    while True:
        choice = input("Enter a device number and press Enter: ").strip()
        if not choice.isdigit():
            print("Please enter a number.")
            continue

        idx = int(choice)
        try:
            info = pa.get_device_info_by_index(idx)
        except Exception:
            print(f"No device found with number {idx}. Please try again.")
            continue

        if info.get("maxInputChannels", 0) <= 0:
            confirm = input(
                f"Device {idx} ('{info['name']}') doesn't report any input "
                f"channels. Use it anyway? (y/N): "
            ).strip().lower()
            if confirm != "y":
                continue

        print(f"Selected: {info['name']}\n")
        return idx, info["name"]


def load_config():
    if os.path.exists(CONFIG_PATH):
        try:
            with open(CONFIG_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def configured_languages(cfg):
    """Return the selected target languages, validating saved settings."""
    selected = cfg.get("selected_languages", list(LANG_TARGETS))
    if not isinstance(selected, list):
        selected = list(LANG_TARGETS)
    return [lang for lang in LANG_TARGETS if lang in selected] or ["zh"]


def configure_runtime(cfg):
    """Apply settings saved by the Tanuki Sub OBS desktop panel."""
    global OUTPUT_FILES, IDLE_CLEAR_SEC, HOLD_AFTER_TURN_SEC, MAX_SUBTITLE_CHARS, AUDIO_GAIN, NOISE_GATE_THRESHOLD
    selected = configured_languages(cfg)
    OUTPUT_FILES = {lang: os.path.join(OUTPUT_DIR, f"subtitle_{lang}.txt") for lang in selected}
    IDLE_CLEAR_SEC = float(cfg.get("idle_clear_sec", IDLE_CLEAR_SEC))
    HOLD_AFTER_TURN_SEC = float(cfg.get("hold_after_turn_sec", HOLD_AFTER_TURN_SEC))
    caps = cfg.get("max_subtitle_chars", {})
    if isinstance(caps, dict):
        for lang in LANG_TARGETS:
            if lang in caps:
                MAX_SUBTITLE_CHARS[lang] = int(caps[lang])
    # Defensive clamping: config.json could have been hand-edited.
    AUDIO_GAIN = max(0.1, min(5.0, float(cfg.get("audio_gain", AUDIO_GAIN))))
    NOISE_GATE_THRESHOLD = max(0, min(5000, int(cfg.get("noise_gate_threshold", NOISE_GATE_THRESHOLD))))
    return selected


def run_setup_wizard(force_key=False, force_mic=False):
    """
    Load/create config.json:
      - Ask for the API key if we don't have one yet (falls back to an
        existing GEMINI_API_KEY / GOOGLE_API_KEY environment variable
        if you'd already set one).
      - Ask you to pick a microphone if we haven't saved one yet, or if
        the saved device is no longer valid (e.g. unplugged, or its
        index shifted after reconnecting).
    force_key / force_mic force a re-prompt (used by --setup).
    """
    cfg = load_config()

    # --- API key: ask only once -------------------------------------------
    if force_key or not cfg.get("gemini_api_key"):
        env_key = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY")
        if env_key and not force_key:
            cfg["gemini_api_key"] = env_key
        else:
            print("=" * 60)
            print("First-time setup: please paste your Gemini API key")
            print("(Get a free one at https://aistudio.google.com/apikey)")
            print("=" * 60)
            key = input("API key: ").strip()
            while not key:
                key = input("Key can't be empty, please paste it again: ").strip()
            cfg["gemini_api_key"] = key

    # --- Microphone: check the saved device is still valid ----------------
    pa = pyaudio.PyAudio()
    mic_still_valid = False
    if not force_mic and cfg.get("mic_device_index") is not None:
        try:
            info = pa.get_device_info_by_index(cfg["mic_device_index"])
            # Names must match too — device numbers can get reassigned
            # after devices are plugged/unplugged.
            mic_still_valid = info.get("name") == cfg.get("mic_device_name")
        except Exception:
            mic_still_valid = False

    if not mic_still_valid:
        idx, name = choose_microphone(pa)
        cfg["mic_device_index"] = idx
        cfg["mic_device_name"] = name

    pa.terminate()
    save_config(cfg)

    print(f"Using microphone: {cfg['mic_device_name']}")
    print("(To change the microphone or API key later, run: python obs_live_subtitles.py --setup)\n")
    return cfg


# ---------------------------------------------------------------------------
# Subtitle writer: writes the latest text to disk for OBS to read
# ---------------------------------------------------------------------------

class SubtitleWriter:
    def __init__(self, languages, write_combined=False):
        self._lock = asyncio.Lock()
        self._texts = {lang: "" for lang in languages}
        self._write_combined = write_combined
        paths = list(OUTPUT_FILES.values())
        if write_combined:
            paths.append(COMBINED_FILE)
        for path in paths:
            open(path, "w", encoding="utf-8").close()

    async def update(self, lang: str, text: str):
        async with self._lock:
            if self._texts[lang] == text:
                return  # nothing changed, skip the disk write / OBS re-render
            self._texts[lang] = text
            with open(OUTPUT_FILES[lang], "w", encoding="utf-8") as f:
                f.write(text)
            if self._write_combined:
                with open(COMBINED_FILE, "w", encoding="utf-8") as f:
                    f.write("\n".join(f"{lang.upper()}: {text}" for lang, text in self._texts.items()))


writer = None


# ---------------------------------------------------------------------------
# Microphone capture: fan the same audio out to all three session queues
# ---------------------------------------------------------------------------

def _downmix_to_mono(raw_bytes: bytes, channels: int) -> bytes:
    """
    Average all channels down to mono. Works for any channel count, not
    just stereo — audioop.tomono() only handles exactly 2 channels, which
    is fine for almost every microphone, but this covers rarer multi-input
    audio interfaces too.
    """
    if channels <= 1:
        return raw_bytes
    samples = array.array("h", raw_bytes)  # 16-bit signed samples
    mono = array.array(
        "h",
        (
            sum(samples[i : i + channels]) // channels
            for i in range(0, len(samples) - channels + 1, channels)
        ),
    )
    return mono.tobytes()


async def mic_capture(queues):
    pa = pyaudio.PyAudio()

    device_index = CONFIG["mic_device_index"]
    info = pa.get_device_info_by_index(device_index)

    device_channels = max(1, int(info["maxInputChannels"]))
    device_rate = int(info["defaultSampleRate"])
    frames_per_buffer = int(device_rate * CHUNK_MS / 1000)

    print(
        f"Capturing from: {info['name']} "
        f"(native channels={device_channels}, native rate={device_rate}Hz)"
    )
    print("Listening... start talking (Ctrl+C to stop)")

    try:
        stream = pa.open(
            format=pyaudio.paInt16,
            channels=device_channels,
            rate=device_rate,
            input=True,
            input_device_index=device_index,
            frames_per_buffer=frames_per_buffer,
        )
    except OSError as e:
        print("\n" + "=" * 60)
        print("Could not open the selected audio device.")
        print(f"Error detail: {e}")
        print("Common causes:")
        print("  - Windows microphone privacy settings are blocking access")
        print("    (Settings > Privacy & security > Microphone > allow")
        print("    desktop apps to access your microphone)")
        print("  - Another app (Discord, Zoom, OBS, etc.) has exclusive")
        print("    control of this device right now")
        print("  - The device was unplugged or disabled after being selected")
        print("Try running 3_reconfigure.bat to pick a different device.")
        print("=" * 60)
        pa.terminate()
        raise

    loop = asyncio.get_event_loop()
    resample_state = None  # carries audioop.ratecv state across chunks for a smooth stream
    try:
        while True:
            raw = await loop.run_in_executor(
                None, stream.read, frames_per_buffer, False
            )
            # multi-channel -> mono
            if device_channels > 1:
                raw = _downmix_to_mono(raw, device_channels)
            # device's native rate -> the 16kHz Gemini requires
            if device_rate != SAMPLE_RATE:
                raw, resample_state = audioop.ratecv(
                    raw, 2, 1, device_rate, SAMPLE_RATE, resample_state
                )
            # Noise gate: mute near-silent chunks (room hiss/background noise)
            # so Gemini isn't fed audio that could be misheard as speech.
            if NOISE_GATE_THRESHOLD > 0 and audioop.rms(raw, 2) < NOISE_GATE_THRESHOLD:
                raw = b"\x00" * len(raw)
            # Manual gain: boost a too-quiet mic or pull down a too-hot one
            # before Gemini sees it. audioop.mul clips instead of wrapping
            # around, so this can never distort into garbage samples.
            if AUDIO_GAIN != 1.0:
                raw = audioop.mul(raw, 2, AUDIO_GAIN)
            for q in queues:
                await q.put(raw)
    finally:
        stream.stop_stream()
        stream.close()
        pa.terminate()


# ---------------------------------------------------------------------------
# Per-language subtitle lifecycle: when to start a new cue, and when to clear
# ---------------------------------------------------------------------------

class SubtitleSession:
    def __init__(self, lang_key: str):
        self.lang_key = lang_key
        self.buffer = ""
        self._clear_task = None
        self.max_chars = MAX_SUBTITLE_CHARS.get(lang_key, 40)
        self._segment_done = False  # True once the current cue is "finalized"

    async def _clear_after(self, delay: float):
        try:
            await asyncio.sleep(delay)
            self.buffer = ""
            self._segment_done = False
            await writer.update(self.lang_key, "")
        except asyncio.CancelledError:
            pass  # new text arrived before the timer fired — that's expected

    def _reschedule_clear(self, delay: float):
        if self._clear_task and not self._clear_task.done():
            self._clear_task.cancel()
        self._clear_task = asyncio.create_task(self._clear_after(delay))

    async def on_text(self, text: str):
        # If the previous cue was already finalized, start a fresh one
        # instead of tacking new text onto the end of it.
        if self._segment_done:
            self.buffer = ""
            self._segment_done = False

        self.buffer += text
        stripped = self.buffer.strip()
        await writer.update(self.lang_key, stripped)
        self._reschedule_clear(IDLE_CLEAR_SEC)

        if stripped and (len(stripped) >= self.max_chars or stripped[-1] in SENTENCE_END_CHARS):
            self._segment_done = True

    async def on_turn_complete(self):
        if self.buffer:
            self._segment_done = True  # next bit of speech starts a new cue
            self._reschedule_clear(HOLD_AFTER_TURN_SEC)

    async def on_interrupted(self):
        if self._clear_task and not self._clear_task.done():
            self._clear_task.cancel()
        self.buffer = ""
        self._segment_done = False
        await writer.update(self.lang_key, "")


# ---------------------------------------------------------------------------
# One language's Live Translate session: send audio in, get transcripts out
# ---------------------------------------------------------------------------

async def translate_session(lang_key: str, target_code: str, in_queue: asyncio.Queue):
    """
    Runs forever. Gemini Live connections are time-limited by Google
    (roughly 10-15 minutes for audio-only sessions), so this wraps the
    connection in a retry loop: if it drops for any reason, it clears
    the stale subtitle and reconnects automatically after a short delay.
    """
    config = types.LiveConnectConfig(
        response_modalities=["AUDIO"],
        input_audio_transcription=types.AudioTranscriptionConfig(),
        output_audio_transcription=types.AudioTranscriptionConfig(),
        translation_config=types.TranslationConfig(
            target_language_code=target_code,
            echo_target_language=True,
        ),
    )

    subtitle = SubtitleSession(lang_key)

    while True:
        try:
            async with client.aio.live.connect(model=MODEL, config=config) as session:
                print(f"[{lang_key}] connected (target={target_code})")

                async def sender():
                    while True:
                        chunk = await in_queue.get()
                        await session.send_realtime_input(
                            audio=types.Blob(data=chunk, mime_type="audio/pcm;rate=16000")
                        )

                async def receiver():
                    async for response in session.receive():
                        sc = response.server_content
                        if not sc:
                            continue

                        if getattr(sc, "interrupted", False):
                            await subtitle.on_interrupted()
                            continue

                        if sc.output_transcription and sc.output_transcription.text:
                            await subtitle.on_text(sc.output_transcription.text)

                        if sc.turn_complete:
                            await subtitle.on_turn_complete()

                await asyncio.gather(sender(), receiver())

        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[{lang_key}] connection dropped ({e}); reconnecting in {RECONNECT_DELAY_SEC:.0f}s...")
            await subtitle.on_interrupted()  # clear stale text so nothing lingers on screen
            await asyncio.sleep(RECONNECT_DELAY_SEC)
            continue


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

async def main():
    languages = configure_runtime(CONFIG)
    global writer
    writer = SubtitleWriter(languages, bool(CONFIG.get("write_combined_file", False)))
    queues = {lang: asyncio.Queue() for lang in languages}

    tasks = [asyncio.create_task(mic_capture(list(queues.values())))]
    for lang in languages:
        target = LANG_TARGETS[lang]
        tasks.append(asyncio.create_task(translate_session(lang, target, queues[lang])))

    await asyncio.gather(*tasks)


if __name__ == "__main__":
    force_setup = "--setup" in sys.argv
    CONFIG = run_setup_wizard(force_key=force_setup, force_mic=force_setup)
    client = genai.Client(api_key=CONFIG["gemini_api_key"])

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nStopped.")
